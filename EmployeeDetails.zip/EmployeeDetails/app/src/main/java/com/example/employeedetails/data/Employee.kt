package com.example.employeedetails.data

data class Employee(var id : Int, var name : String,var contact : String, var email : String)